a = 3.14
print('{:.3f}'.format(a))