
#data parameters
DATA_ROOT_PATH = ''
BATCH_SIZE = 64
INPUT_SIZE = 32

#train_parameters
INITIAL_LR = 0.001
MOMENTUM = 0.9
WEIGHT_DECAY = 0.0005
MAX_EPOCHS = 21
TRAIN_LOGS = './logs'
DISP_INTERVAL = 50
PLT_TRAIN_LOSS = 2

#validation parameters
PLT_ACC = 2
