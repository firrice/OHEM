import torch
import torch.nn as nn
import torch.nn.functional as F

class MNIST_net(nn.Module):
    def __init__(self):
        super(MNIST_net , self).__init__()
        self.conv1 = nn.Conv2d(in_channels=1, out_channels=10, kernel_size=5)
        self.conv2 = nn.Conv2d(10, 20, 5)
        self.conv3 = nn.Conv2d(20, 40, 3)

        self.mp = nn.MaxPool2d(2)
        # fully connect
        self.fc = nn.Linear(40, 10)  # （in_features, out_features）

    def forward(self, x):
        # in_size = 64
        in_size = x.size(0)  #batch_size
        # x: 64*1*28*28
        x = F.relu(self.mp(self.conv1(x)))
        # x: 64*10*12*12  feature map =[(28-4)/2]^2=12*12
        x = F.relu(self.mp(self.conv2(x)))
        # x: 64*20*4*4
        x = F.relu(self.mp(self.conv3(x)))

        x = x.view(in_size, -1)
        x = self.fc(x)
        return F.log_softmax(x)  # 64*10