import matplotlib.pyplot as plt
import numpy as np

plt_txt = open('./train_scripts/train_OHEM.txt' , 'r')
lines = plt_txt.readlines()
fig = plt.figure(1)
ax1 = plt.subplot(1 , 2 , 1)
ax2 = plt.subplot(1 , 2 , 2)
plt_epoch = np.linspace(0 , 20 , 11)
for i , line in enumerate(lines):
    line = line.strip()
    line = line.split(' ')
    if(i == 0):
        plt_train_loss = []
        for i in range(len(line)):
            plt_train_loss.append(line[i])
        plt.sca(ax1)
        plt.xlabel('epoch')
        plt.ylabel('train_loss')
        plt.plot(plt_epoch , plt_train_loss)
    if(i == 1):
        plt_val_acc = []
        for i in range(len(line)):
            plt_val_acc.append(line[i])
        plt.sca(ax2)
        plt.xlabel('epoch')
        plt.ylabel('val_acc')
        plt.plot(plt_epoch , plt_val_acc)
plt.suptitle('train_OHEM')
plt.show()


