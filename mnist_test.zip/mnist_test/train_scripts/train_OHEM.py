import torch
from torchvision.datasets import MNIST
from torchvision import transforms
from torch.utils import data
import torch.nn as nn
import torch
from model import MNIST_net
import config as cfg
import numpy as np
import matplotlib.pyplot as plt

def ohem_loss(output , label, loss_class , K_hard):
    batch_size = output.size()[0]
    loss = loss_class(output , label)
    sorted_loss , index = torch.sort(loss , descending = True)
    if(K_hard < batch_size):
        hard_index = index[ : K_hard]
        final_loss = loss[hard_index].sum() / K_hard
    else:
        final_loss = loss.sum() / batch_size
    return final_loss

class solver(object):
    def __init__(self , train_dataset , test_dataset , net):
        self.train_dataset = train_dataset
        self.test_dataset = test_dataset
        self.train_loader = data.DataLoader(train_dataset , batch_size = cfg.BATCH_SIZE , shuffle = True , pin_memory = False ,
                                            num_workers = 0 , drop_last = False)
        self.train_count = len(train_dataset)
        self.test_loader = data.DataLoader(test_dataset, batch_size=cfg.BATCH_SIZE, shuffle=True, pin_memory=False,
                                            num_workers=0, drop_last=False)
        self.test_count = len(test_dataset)
        self.net = net.cuda()
        self.loss_class = nn.CrossEntropyLoss(reduction = 'none').cuda()
        self.optimizer = torch.optim.Adam(params = self.net.parameters() , lr = cfg.INITIAL_LR , betas = (0.9 , 0.99))
        self.K_hard = 12

    def train(self):
        plt_train_loss = []
        plt_val_acc = []
        plt_txt = open('./train_OHEM.txt' , 'a')
        for EPOCH in range(cfg.MAX_EPOCHS):
            index = 0
            train_loss_per_epoch = 0.0
            #=================validation phase=================================
            num_correct = 0.0
            for i, (img, label) in enumerate(self.test_loader):
                img = img.cuda()
                output = self.net(img)
                _, pred = output.max(1)
                pred = pred.cpu().detach()
                num_correct += (pred == label).sum()
            num_correct = int(num_correct)
            acc = num_correct / self.test_count
            print('Validation acc: {0:.3f}'.format(acc))
            if(EPOCH % cfg.PLT_ACC == 0):
                plt_val_acc.append(acc)
            #=====================train phase===================================
            for i , (img , label) in enumerate(self.train_loader):
                img = img.cuda()
                label = label.cuda()
                output = self.net(img)
                loss = ohem_loss(output , label , self.loss_class , self.K_hard)
                self.optimizer.zero_grad()
                loss.backward()
                self.optimizer.step()
                if(i % cfg.DISP_INTERVAL == 0):
                    loss = float(loss.cpu().detach())
                    train_loss_per_epoch += loss
                    index += 1
                    print('Train loss: Epoch {} , iter {} ,loss is{}'.format(EPOCH , i , loss))
            train_loss_per_epoch /= index
            if(EPOCH % cfg.PLT_TRAIN_LOSS == 0):
                plt_train_loss.append(train_loss_per_epoch)
        for i in range(len(plt_train_loss)):
            plt_txt.write(str(plt_train_loss[i]) + ' ')
        plt_txt.write('\n')
        for i in range(len(plt_val_acc)):
            plt_txt.write(str(plt_val_acc[i]) + ' ')
        plt_txt.close()

def main():
    train_dataset = MNIST('./mnist' , train = True , download = True , transform = transforms.ToTensor())
    test_dataset = MNIST('./mnist' , train = False , download = True , transform = transforms.ToTensor())
    net = MNIST_net()
    Solver = solver(train_dataset , test_dataset , net)
    print('start training...')
    Solver.train()
    print('training end!')


if __name__ == '__main__':
    main()